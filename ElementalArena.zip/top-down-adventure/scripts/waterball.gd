
extends CharacterBody2D

@export var speed: float = 400.0

var direction: Vector2 = Vector2.RIGHT
var bounces_left: int = 2
var shooter: CharacterBody2D

func _physics_process(delta):
	var collision = move_and_collide(direction * speed * delta)

	if collision:
		var collider = collision.get_collider()

		if collider == shooter:
			return

		if collider.is_in_group("fire_player"):
			collider.take_damage()
			queue_free()
			return
			
		if collider.is_in_group("water_player"):
			return

		direction = direction.bounce(
			collision.get_normal()
		).normalized()

		bounces_left -= 1

		if bounces_left <= 0:
			queue_free()
