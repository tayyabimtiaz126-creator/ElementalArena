
extends CharacterBody2D

@export var speed: float = 250.0
@export var projectile_scene: PackedScene

var last_direction = Vector2.LEFT
var health: int = 3

func _physics_process(_delta):
	var direction = Input.get_vector(
		"p2_left",
		"p2_right",
		"p2_up",
        "p2_down"
	)

	if direction != Vector2.ZERO:
		last_direction = direction

	velocity = direction * speed
	move_and_slide()

	if Input.is_action_just_pressed("p2_shoot"):
		shoot()

func shoot():
	if projectile_scene == null:
		return

	var projectile = projectile_scene.instantiate()
	projectile.direction = last_direction
	projectile.shooter = self
	projectile.global_position = global_position + last_direction * 30

	get_tree().current_scene.get_node("Projectiles").add_child(projectile)

func take_damage():
	health -= 1
	$HealthBar.value = health
	print(name, " Health: ", health)
	if health <= 0:
		get_tree().current_scene.game_over("FIRE PLAYER WINS!")
		queue_free()
