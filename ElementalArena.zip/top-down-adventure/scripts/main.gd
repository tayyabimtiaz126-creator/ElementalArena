extends Node2D

@onready var panel = $GameOverUI/Panel
@onready var winner_label = $GameOverUI/Panel/WinnerLabel
@onready var play_again_button = $GameOverUI/Panel/PlayAgainButton

func _ready():
	panel.hide()
	$GameOverUI.process_mode = Node.PROCESS_MODE_ALWAYS

	play_again_button.pressed.connect(_on_play_again_pressed)

func game_over(winner_text: String):
	winner_label.text = winner_text
	panel.show()
	get_tree().paused = true

func _on_play_again_pressed():
	get_tree().paused = false
	get_tree().reload_current_scene()
